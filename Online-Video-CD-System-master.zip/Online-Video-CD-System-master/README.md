# Online-Video-CD-System
There are two main actors of application who will interact directly with the application. Admin and a user. 
Admin can add, edit, delete the vcd and the user can view, search, buy and also add vcd. 
Techonoly Used in the project Online VCD System:
1) Front-End : JSP, Servlet, Bootstrap, HTML, CSS, STL
2) Back-End : MYSQL 
3) Server : Tomcat 8.5
